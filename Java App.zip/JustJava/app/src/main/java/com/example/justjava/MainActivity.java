package com.example.justjava;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import java.text.Format;

import org.w3c.dom.Text;

import java.text.NumberFormat;
import java.util.Currency;


public class MainActivity extends AppCompatActivity {

    public int orderCount = 1;
    public int currentPrice = 0;
    public int coffeCost = 2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //Find order button in xml file
        final Button btn_order = (Button) findViewById(R.id.btn_order);
        orderCount = 0;

        TextView tx_orderCount = findViewById(R.id.tx_count);
        tx_orderCount.setText(Integer.toString(orderCount));

        TextView tx_ordered = findViewById(R.id.ordered);
        tx_ordered.setVisibility(View.INVISIBLE);
    }

    //This method called when button are pressed
    public void submitOrder(View view){

        TextView tx_ordered = findViewById(R.id.ordered);
        tx_ordered.setVisibility(View.VISIBLE);
        tx_ordered.setText("You ordered  :  " + Integer.toString(orderCount) + "   Coffies for a: " + NumberFormat.getCurrencyInstance().format(currentPrice));

        displayPrice(currentPrice);
    }

    public void increaseOrderCount(View view){

        orderCount++;
        increasePrice();
        display(orderCount);

        TextView tx_price = findViewById(R.id.price);
        displayPrice(currentPrice);
    }

    public void increasePrice(){

        currentPrice += coffeCost;
    }

    public void decreasePrice(){


            currentPrice -= coffeCost;
    }

    public void decreaseOrderCount(View view){

        if(orderCount >= 0 ) {
            orderCount--;
            decreasePrice();
            display(orderCount);
            displayPrice(currentPrice);
        }
    }

    //This method displays the given qunantity on text view
    private void display(int number){

        TextView quantity = (TextView) findViewById(R.id.tx_count);
        quantity.setText(" " + number);
    }

    private void displayPrice(int price){
        TextView tx_price = (TextView) findViewById(R.id.price);
        tx_price.setText(NumberFormat.getCurrencyInstance().format(price));
    }
}
